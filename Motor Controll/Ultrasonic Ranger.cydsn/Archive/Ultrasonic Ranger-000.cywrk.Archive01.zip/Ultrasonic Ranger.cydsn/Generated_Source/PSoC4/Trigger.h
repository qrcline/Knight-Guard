/*******************************************************************************
* File Name: Trigger.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Trigger_H) /* Pins Trigger_H */
#define CY_PINS_Trigger_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Trigger_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Trigger_Write(uint8 value) ;
void    Trigger_SetDriveMode(uint8 mode) ;
uint8   Trigger_ReadDataReg(void) ;
uint8   Trigger_Read(void) ;
uint8   Trigger_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Trigger_DRIVE_MODE_BITS        (3)
#define Trigger_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Trigger_DRIVE_MODE_BITS))
#define Trigger_DRIVE_MODE_SHIFT       (0x00u)
#define Trigger_DRIVE_MODE_MASK        (0x07u << Trigger_DRIVE_MODE_SHIFT)

#define Trigger_DM_ALG_HIZ         (0x00u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_DIG_HIZ         (0x01u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_RES_UP          (0x02u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_RES_DWN         (0x03u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_OD_LO           (0x04u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_OD_HI           (0x05u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_STRONG          (0x06u << Trigger_DRIVE_MODE_SHIFT)
#define Trigger_DM_RES_UPDWN       (0x07u << Trigger_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define Trigger_MASK               Trigger__MASK
#define Trigger_SHIFT              Trigger__SHIFT
#define Trigger_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Trigger_PS                     (* (reg32 *) Trigger__PS)
/* Port Configuration */
#define Trigger_PC                     (* (reg32 *) Trigger__PC)
/* Data Register */
#define Trigger_DR                     (* (reg32 *) Trigger__DR)
/* Input Buffer Disable Override */
#define Trigger_INP_DIS                (* (reg32 *) Trigger__PC2)


#if defined(Trigger__INTSTAT)  /* Interrupt Registers */

    #define Trigger_INTSTAT                (* (reg32 *) Trigger__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins Trigger_H */


/* [] END OF FILE */
