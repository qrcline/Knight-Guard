/*******************************************************************************
* File Name: Echo.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Echo_H) /* Pins Echo_H */
#define CY_PINS_Echo_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Echo_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Echo_Write(uint8 value) ;
void    Echo_SetDriveMode(uint8 mode) ;
uint8   Echo_ReadDataReg(void) ;
uint8   Echo_Read(void) ;
uint8   Echo_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Echo_DRIVE_MODE_BITS        (3)
#define Echo_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Echo_DRIVE_MODE_BITS))
#define Echo_DRIVE_MODE_SHIFT       (0x00u)
#define Echo_DRIVE_MODE_MASK        (0x07u << Echo_DRIVE_MODE_SHIFT)

#define Echo_DM_ALG_HIZ         (0x00u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_DIG_HIZ         (0x01u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_RES_UP          (0x02u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_RES_DWN         (0x03u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_OD_LO           (0x04u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_OD_HI           (0x05u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_STRONG          (0x06u << Echo_DRIVE_MODE_SHIFT)
#define Echo_DM_RES_UPDWN       (0x07u << Echo_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define Echo_MASK               Echo__MASK
#define Echo_SHIFT              Echo__SHIFT
#define Echo_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Echo_PS                     (* (reg32 *) Echo__PS)
/* Port Configuration */
#define Echo_PC                     (* (reg32 *) Echo__PC)
/* Data Register */
#define Echo_DR                     (* (reg32 *) Echo__DR)
/* Input Buffer Disable Override */
#define Echo_INP_DIS                (* (reg32 *) Echo__PC2)


#if defined(Echo__INTSTAT)  /* Interrupt Registers */

    #define Echo_INTSTAT                (* (reg32 *) Echo__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins Echo_H */


/* [] END OF FILE */
