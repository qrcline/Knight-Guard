/* ========================================
 *
 * Copyleft by Shahariar,2015
 * All Rights Released
 * OPEN SOFTWARE, NO WARRENTY 
 *
 * DODGY BROTHERS C CODING Inc.  
 * BUG may appear in Future !!!
 * Non-Precision UltraSonic Ranger,
 * ========================================
*/

#include <project.h>

// Initial time ,set  here
int16 i =0;
int distance=0;

//CY ISR is a macro for interrupt handling
// http://www.cypress.com/go/an90799 for detalis
CY_ISR(Timer_ISR_handler)
{
    // at 1MHz Timer clock each count is 1 micro Second
    Timer_ClearInterrupt(Timer_INTR_MASK_CC_MATCH);
    i= Timer_ReadCounter();    
    
    // from HC 04 Ultra Sonic module's datasheet, each 58 uS = 1 cm
    
    distance =i/58;
    // please note that measured distance above 400 cm is not reliable
    
}

int main()

{
// Start Timer
    Timer_Start();
// Enable Global Interrupt and start ISR  
    CyGlobalIntEnable; 
    ISR_StartEx(Timer_ISR_handler);
    //SetTime_ISR_Start();
    
//  Supply 5 Vdd to LCD display from MCU and power up Back Light  
    Power_Up_LCD_Pin_1_Write(1);
    Back_Light_On_N_Write(0);
    Back_Light_On_P_Write(1);

// Start LCD display    
    LCD_Char_Start();
    LCD_Char_DisplayOn();
    
             
        for(;;)
        {
    // for proper application, delay should not be used, 
    // instead a preiodic interrupt or a function call is recommended
    CyDelay(500);
    
    // Triggers the Ultra Sonic Sensor 
    Trigger_Write(1);
    LED_Write(1);
    CyDelayUs(10);
    // for 10 uS
    Trigger_Write(0);
    LED_Write(0);
    
    LCD_Char_ClearDisplay();
   
    
    LCD_Char_Position(0,0);
    LCD_Char_PrintString("PSoC SonicRANGER");
    
    LCD_Char_Position(1,0);
    LCD_Char_PrintString("Distance: ");
    
    LCD_Char_Position(1,10);
    LCD_Char_PrintNumber(distance);
    
    LCD_Char_Position(1,14);
    LCD_Char_PrintString("cm");
    
    
    
}
          
}
/* [] END OF FILE */
